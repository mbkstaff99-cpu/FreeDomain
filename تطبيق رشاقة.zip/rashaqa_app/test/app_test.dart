import 'package:flutter_test/flutter_test.dart';
import 'package:rashaqa/models.dart';
import 'package:rashaqa/utils/arabic.dart';
import 'package:rashaqa/utils/format.dart';
import 'package:rashaqa/utils/nutrition.dart';

void main() {
  test('normalizeAr يوحّد الهمزات والتاء المربوطة والألف المقصورة', () {
    expect(normalizeAr('أرز'), normalizeAr('ارز'));
    expect(normalizeAr('دجاجة'), 'دجاجه');
    expect(normalizeAr('موسى'), 'موسي');
  });

  test('parseNum يدعم الأرقام العربية والفاصلة', () {
    expect(parseNum('٣٣٫٥'), 33.5);
    expect(parseNum('8,5'), 8.5);
    expect(parseNum(''), 0);
  });

  test('fmtInt و fmtNum', () {
    expect(fmtInt(2500), '2,500');
    expect(fmtInt(1320), '1,320');
    expect(fmtNum(8.5), '8.5');
    expect(fmtNum(33.0), '33');
  });

  test('calcTargets لذكر 66 كغ و187 سم و26 سنة، متوسط النشاط، بناء عضلات', () {
    final t = calcTargets(const Profile(
      name: 'x',
      weight: 66,
      height: 187,
      age: 26,
      sex: 'm',
      activity: 'mid',
      goal: 'gain',
    ));
    expect(t.kcal, 2940);
    expect(t.protein, 132);
  });
}
