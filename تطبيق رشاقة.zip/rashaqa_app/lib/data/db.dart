import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

import '../models.dart';

/// طبقة قاعدة البيانات المحلية (SQLite): سجل الوجبات وأطعمة المستخدم.
class AppDb {
  static Database? _db;

  static Future<Database> get() async {
    if (_db != null) return _db!;
    final path = p.join(await getDatabasesPath(), 'rashaqa.db');
    _db = await openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE entries (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            date TEXT NOT NULL,
            meal_type TEXT NOT NULL,
            name TEXT NOT NULL,
            grams REAL, kcal REAL, protein REAL, carbs REAL, fat REAL,
            created_at TEXT
          )''');
        await db.execute('CREATE INDEX idx_entries_date ON entries(date)');
        // أطعمة المستخدم: بلا أي قيود CHECK (حرية كاملة في القيم). القيم لكل 100 غ.
        await db.execute('''
          CREATE TABLE user_foods (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            kcal REAL, protein REAL, carbs REAL, fat REAL,
            created_at TEXT
          )''');
      },
    );
    return _db!;
  }

  // ───────── سجل الوجبات ─────────
  static Future<List<Entry>> entriesForDate(String date) async {
    final db = await get();
    final rows = await db.query('entries',
        where: 'date = ?', whereArgs: [date], orderBy: 'id ASC');
    return rows.map(Entry.fromMap).toList();
  }

  static Future<int> insertEntry(Entry e) async {
    final db = await get();
    return db.insert('entries', e.toMap());
  }

  static Future<void> deleteEntry(int id) async {
    final db = await get();
    await db.delete('entries', where: 'id = ?', whereArgs: [id]);
  }

  static Future<void> deleteMeal(String date, String mealType) async {
    final db = await get();
    await db.delete('entries',
        where: 'date = ? AND meal_type = ?', whereArgs: [date, mealType]);
  }

  /// مجاميع كل يوم بين تاريخين (شاملين). المفتاح yyyy-MM-dd.
  static Future<Map<String, Totals>> dailyTotals(String from, String to) async {
    final db = await get();
    final rows = await db.rawQuery(
      'SELECT date, SUM(kcal) AS k, SUM(protein) AS p, SUM(carbs) AS c, SUM(fat) AS f '
      'FROM entries WHERE date >= ? AND date <= ? GROUP BY date',
      [from, to],
    );
    double d(Object? v) => (v as num?)?.toDouble() ?? 0;
    final out = <String, Totals>{};
    for (final r in rows) {
      out[r['date'] as String] = Totals(d(r['k']), d(r['p']), d(r['c']), d(r['f']));
    }
    return out;
  }

  // ───────── أطعمة المستخدم ─────────
  static Future<List<Food>> userFoods() async {
    final db = await get();
    final rows = await db.query('user_foods', orderBy: 'id DESC');
    double d(Object? v) => (v as num?)?.toDouble() ?? 0;
    return rows
        .map((r) => Food(
              id: r['id'] as int?,
              name: r['name'] as String,
              category: 'أطعمتي',
              kcal: d(r['kcal']),
              protein: d(r['protein']),
              carbs: d(r['carbs']),
              fat: d(r['fat']),
              custom: true,
            ))
        .toList();
  }

  static Future<void> insertUserFood(Food f) async {
    final db = await get();
    await db.insert('user_foods', {
      'name': f.name,
      'kcal': f.kcal,
      'protein': f.protein,
      'carbs': f.carbs,
      'fat': f.fat,
      'created_at': DateTime.now().toIso8601String(),
    });
  }

  static Future<void> deleteUserFood(int id) async {
    final db = await get();
    await db.delete('user_foods', where: 'id = ?', whereArgs: [id]);
  }

  static Future<void> clearAll() async {
    final db = await get();
    await db.delete('entries');
    await db.delete('user_foods');
  }
}
