import 'dart:convert';

import 'package:flutter/services.dart' show rootBundle;

import '../models.dart';
import '../utils/arabic.dart';

/// مكتبة الأطعمة المدمجة (assets/foods.json).
/// لاحقاً: يمكن استبدالها بقاعدة foods.sqlite الناتجة عن سكربت الاستيراد
/// دون تغيير باقي التطبيق (يكفي تعديل هذا الصف فقط).
class FoodRepository {
  List<Food> _library = const [];
  List<String> _categories = const [];
  // اسم مطبّع لكل طعام لتسريع البحث.
  List<String> _normNames = const [];

  List<String> get categories => _categories;
  int get count => _library.length;

  Future<void> load() async {
    final raw = await rootBundle.loadString('assets/foods.json');
    final list = jsonDecode(raw) as List<dynamic>;
    _library = list.map((e) => Food.fromList(e as List<dynamic>)).toList();
    _normNames = _library.map((f) => normalizeAr(f.name)).toList();
    final seen = <String>{};
    final cats = <String>[];
    for (final f in _library) {
      if (seen.add(f.category)) cats.add(f.category);
    }
    _categories = cats;
  }

  /// بحث بكلمات متعددة (كل الكلمات يجب أن تتطابق) مع تصفية بالتصنيف.
  /// [extra] أطعمة المستخدم تظهر أولاً.
  List<Food> search(String query,
      {String category = 'الكل', List<Food> extra = const []}) {
    final tokens =
        normalizeAr(query).split(RegExp(r'\s+')).where((t) => t.isNotEmpty).toList();
    bool match(String norm) => tokens.every(norm.contains);

    final out = <Food>[];
    if (category == 'الكل' || category == 'أطعمتي') {
      for (final f in extra) {
        if (match(normalizeAr(f.name))) out.add(f);
      }
    }
    if (category != 'أطعمتي') {
      for (var i = 0; i < _library.length; i++) {
        final f = _library[i];
        if (category != 'الكل' && f.category != category) continue;
        if (match(_normNames[i])) out.add(f);
      }
    }
    return out;
  }
}
