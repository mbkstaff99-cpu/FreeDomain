import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../state/app_state.dart';
import '../theme.dart';
import '../utils/format.dart';
import '../widgets/common.dart';
import 'goals.dart';

class MoreScreen extends StatelessWidget {
  const MoreScreen({super.key});

  void _soon(BuildContext context) {
    ScaffoldMessenger.of(context)
        .showSnackBar(const SnackBar(content: Text('قريباً')));
  }

  Future<void> _editName(BuildContext context, AppState st) async {
    final ctrl = TextEditingController(text: st.profile.name);
    final name = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: C.card,
        title: const Text('الاسم'),
        content: TextField(controller: ctrl, autofocus: true),
        actions: [
          TextButton(
              onPressed: () => Navigator.of(ctx).pop(),
              child: const Text('إلغاء')),
          TextButton(
              onPressed: () => Navigator.of(ctx).pop(ctrl.text.trim()),
              child: const Text('حفظ')),
        ],
      ),
    );
    ctrl.dispose();
    if (name != null && name.isNotEmpty) {
      await st.saveProfile(st.profile.copyWith(name: name), st.targets);
    }
  }

  Future<void> _wipe(BuildContext context, AppState st) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: C.card,
        title: const Text('مسح كل بياناتي؟'),
        content: const Text(
            'سيتم حذف سجل الوجبات وأطعمتي المحفوظة وبياناتك وأهدافك من هذا الجهاز، ولا يمكن التراجع.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.of(ctx).pop(false),
              child: const Text('إلغاء')),
          TextButton(
              onPressed: () => Navigator.of(ctx).pop(true),
              child: const Text('مسح', style: TextStyle(color: C.danger))),
        ],
      ),
    );
    if (ok == true) await st.clearAll();
  }

  Widget _tile(IconData icon, String label, VoidCallback onTap,
      {String? trailing, bool first = false}) {
    return Column(
      children: [
        if (!first) const Divider(height: 1),
        InkWell(
          onTap: onTap,
          child: ConstrainedBox(
            constraints: const BoxConstraints(minHeight: 54),
            child: Row(
              children: [
                Icon(icon, color: C.muted, size: 22),
                const SizedBox(width: 14),
                Expanded(child: Text(label, style: const TextStyle(fontSize: 16))),
                if (trailing != null)
                  Text(trailing,
                      style: const TextStyle(fontSize: 14, color: C.muted)),
              ],
            ),
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final st = context.watch<AppState>();
    final pr = st.profile;
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
        children: [
          const SizedBox(
            height: 44,
            child: Center(
              child: Text('المزيد',
                  style: TextStyle(fontSize: 19, fontWeight: FontWeight.w700)),
            ),
          ),
          const SizedBox(height: 8),
          AppCard(
            radius: 18,
            onTap: () => Navigator.of(context)
                .push(MaterialPageRoute(builder: (_) => const GoalsScreen())),
            child: Row(
              children: [
                Container(
                  width: 60,
                  height: 60,
                  decoration:
                      const BoxDecoration(color: C.ring, shape: BoxShape.circle),
                  child: const Icon(Icons.person_outline, color: C.muted, size: 32),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(pr.name,
                          style: const TextStyle(
                              fontSize: 19, fontWeight: FontWeight.w800)),
                      Text('هدفك: ${goalNames[pr.goal] ?? ''}',
                          style: const TextStyle(fontSize: 13, color: C.muted)),
                    ],
                  ),
                ),
                const Icon(Icons.chevron_right, color: C.muted),
              ],
            ),
          ),
          const SizedBox(height: 12),
          AppCard(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Column(
              children: [
                _tile(Icons.flag_outlined, 'أهدافي وبياناتي', () {
                  Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => const GoalsScreen()));
                }, first: true),
                _tile(Icons.badge_outlined, 'الاسم', () => _editName(context, st),
                    trailing: pr.name),
                _tile(Icons.notifications_none, 'إشعارات', () => _soon(context)),
                _tile(Icons.language, 'اللغة', () {}, trailing: 'العربية'),
                _tile(Icons.help_outline, 'المساعدة والدعم', () => _soon(context)),
                _tile(Icons.ios_share, 'مشاركة التطبيق', () => _soon(context)),
                _tile(Icons.star_border, 'تقييم التطبيق', () => _soon(context)),
              ],
            ),
          ),
          const SizedBox(height: 16),
          OutlinedButton(
            onPressed: () => _wipe(context, st),
            style: OutlinedButton.styleFrom(
              minimumSize: const Size.fromHeight(54),
              foregroundColor: C.danger,
              backgroundColor: C.dangerBg,
              side: const BorderSide(color: C.dangerBorder),
              shape:
                  RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
            ),
            child: const Text('مسح بياناتي',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
          ),
        ],
      ),
    );
  }
}
