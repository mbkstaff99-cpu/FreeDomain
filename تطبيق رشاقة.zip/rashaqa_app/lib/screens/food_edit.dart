import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models.dart';
import '../state/app_state.dart';
import '../theme.dart';
import '../utils/format.dart';
import '../widgets/common.dart';

/// إضافة طعام (من المكتبة أو يدوي). كل القيم حرة التعديل بلا أي حدود.
/// القيم المعروضة تخص الكمية بالغرام، وتتناسب تلقائياً عند تغيير الكمية.
class FoodEditScreen extends StatefulWidget {
  final Food? food;
  const FoodEditScreen({super.key, this.food});

  @override
  State<FoodEditScreen> createState() => _FoodEditScreenState();
}

class _FoodEditScreenState extends State<FoodEditScreen> {
  final TextEditingController _name = TextEditingController();
  final TextEditingController _grams = TextEditingController(text: '100');
  final TextEditingController _p = TextEditingController();
  final TextEditingController _c = TextEditingController();
  final TextEditingController _f = TextEditingController();
  final TextEditingController _k = TextEditingController();

  // القيم لكل 100 غ: [بروتين، كارب، دهون، سعرات]
  final List<double> _per100 = [0, 0, 0, 0];
  bool _saveCustom = false;

  @override
  void initState() {
    super.initState();
    final f = widget.food;
    if (f != null) {
      _name.text = f.name;
      _per100[0] = f.protein;
      _per100[1] = f.carbs;
      _per100[2] = f.fat;
      _per100[3] = f.kcal;
    }
    _refill();
  }

  @override
  void dispose() {
    _name.dispose();
    _grams.dispose();
    _p.dispose();
    _c.dispose();
    _f.dispose();
    _k.dispose();
    super.dispose();
  }

  double get _g => parseNum(_grams.text);

  void _refill() {
    final g = _g;
    _p.text = fmtNum(_per100[0] * g / 100);
    _c.text = fmtNum(_per100[1] * g / 100);
    _f.text = fmtNum(_per100[2] * g / 100);
    _k.text = (_per100[3] * g / 100).round().toString();
  }

  void _onGrams(String _) {
    if (_g > 0) _refill();
  }

  void _setGrams(double v) {
    _grams.text = fmtNum(v < 0 ? 0 : v);
    _onGrams('');
    setState(() {});
  }

  void _onMacro(int i, String s) {
    final g = _g;
    if (g > 0) _per100[i] = parseNum(s) * 100 / g;
  }

  void _calcKcal() {
    final k = 4 * parseNum(_p.text) + 4 * parseNum(_c.text) + 9 * parseNum(_f.text);
    _k.text = k.round().toString();
    _onMacro(3, _k.text);
  }

  Future<void> _add() async {
    final name = _name.text.trim();
    final messenger = ScaffoldMessenger.of(context);
    if (name.isEmpty) {
      messenger.showSnackBar(const SnackBar(content: Text('اكتب اسم الطعام أولاً')));
      return;
    }
    final st = context.read<AppState>();
    final entry = Entry(
      date: st.dateStr,
      mealType: st.currentMealType,
      name: name,
      grams: _g,
      kcal: parseNum(_k.text),
      protein: parseNum(_p.text),
      carbs: parseNum(_c.text),
      fat: parseNum(_f.text),
    );
    await st.addEntry(entry);
    if (_saveCustom && widget.food == null) {
      await st.addUserFood(Food(
        name: name,
        category: 'أطعمتي',
        kcal: _per100[3],
        protein: _per100[0],
        carbs: _per100[1],
        fat: _per100[2],
        custom: true,
      ));
    }
    if (!mounted) return;
    Navigator.of(context).popUntil((r) => r.isFirst);
    st.setTab(0);
    messenger.showSnackBar(SnackBar(
      content: Text('تمت إضافة "$name" إلى ${mealTypeNames[entry.mealType]}'),
    ));
  }

  Widget _label(String t) => Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: Text(t, style: const TextStyle(fontSize: 14, color: C.muted)),
      );

  Widget _macroRow({
    required String label,
    required IconData icon,
    required Color fg,
    required Color bg,
    required TextEditingController ctrl,
    required String unit,
    required int index,
    Color? border,
  }) {
    return AppCard(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
      child: Row(
        children: [
          IconBox(icon: icon, fg: fg, bg: bg),
          const SizedBox(width: 12),
          Expanded(
            child: Text(label,
                style: const TextStyle(fontSize: 15, color: C.muted)),
          ),
          NumBox(
            controller: ctrl,
            color: fg,
            width: 104,
            semanticLabel: label,
            borderColor: border ?? C.border,
            onChanged: (s) => _onMacro(index, s),
          ),
          SizedBox(
            width: 40,
            child: Text(unit,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 12, color: C.muted)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final st = context.watch<AppState>();
    final isNew = widget.food == null;
    return Scaffold(
      appBar: AppBar(title: Text(isNew ? 'إضافة طعام يدوي' : 'إضافة طعام')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
        children: [
          _label('اسم الطعام'),
          TextBox(controller: _name, hint: 'مثال: شوفان'),
          if (widget.food?.estimate ?? false)
            const Padding(
              padding: EdgeInsets.only(top: 8),
              child: Text('هذه قيمة تقديرية، عدّل الأرقام حسب وصفتك أو الملصق الغذائي.',
                  style: TextStyle(fontSize: 12, color: C.carbs)),
            ),
          const SizedBox(height: 16),
          _label('الكمية (غرام) — القيم أدناه تخص هذه الكمية'),
          Row(
            children: [
              IconButton.outlined(
                tooltip: 'زيادة 10 غرام',
                onPressed: () => _setGrams(_g + 10),
                style: IconButton.styleFrom(
                    minimumSize: const Size(52, 52), backgroundColor: C.card),
                icon: const Icon(Icons.add),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Semantics(
                  label: 'الكمية بالغرام',
                  textField: true,
                  child: TextField(
                    controller: _grams,
                    onChanged: _onGrams,
                    textAlign: TextAlign.center,
                    keyboardType:
                        const TextInputType.numberWithOptions(decimal: true),
                    style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
                    decoration: InputDecoration(
                      filled: true,
                      fillColor: C.card,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(14),
                        borderSide: const BorderSide(color: C.border),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(14),
                        borderSide: const BorderSide(color: C.border),
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              IconButton.outlined(
                tooltip: 'إنقاص 10 غرام',
                onPressed: () => _setGrams(_g - 10),
                style: IconButton.styleFrom(
                    minimumSize: const Size(52, 52), backgroundColor: C.card),
                icon: const Icon(Icons.remove),
              ),
            ],
          ),
          const SizedBox(height: 16),
          _macroRow(
              label: 'البروتين',
              icon: Icons.hexagon_outlined,
              fg: C.protein,
              bg: C.proteinBg,
              ctrl: _p,
              unit: 'غ',
              index: 0),
          const SizedBox(height: 8),
          _macroRow(
              label: 'الكربوهيدرات',
              icon: Icons.grain,
              fg: C.carbs,
              bg: C.carbsBg,
              ctrl: _c,
              unit: 'غ',
              index: 1),
          const SizedBox(height: 8),
          _macroRow(
              label: 'الدهون',
              icon: Icons.water_drop_outlined,
              fg: C.fat,
              bg: C.fatBg,
              ctrl: _f,
              unit: 'غ',
              index: 2),
          const SizedBox(height: 8),
          _macroRow(
              label: 'السعرات الحرارية',
              icon: Icons.local_fire_department_outlined,
              fg: C.green,
              bg: C.greenDark,
              ctrl: _k,
              unit: 'سعرة',
              index: 3,
              border: C.greenBorder),
          const SizedBox(height: 12),
          SoftGreenButton(
            label: 'احسب السعرات من البروتين والكربوهيدرات والدهون (اختياري)',
            onPressed: _calcKcal,
          ),
          const SizedBox(height: 8),
          const Text(
            'كل القيم حرة التعديل بلا حدود، أدخل الأرقام كما تراها على الملصق الغذائي أو كما تريد.',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 12, color: C.muted, height: 1.6),
          ),
          if (isNew)
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              activeColor: C.green,
              title: const Text('حفظ في أطعمتي لاستخدامه لاحقاً'),
              value: _saveCustom,
              onChanged: (v) => setState(() => _saveCustom = v),
            ),
          const SizedBox(height: 8),
          _label('أضف إلى:'),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (final e in mealTypeNames.entries)
                ChoiceBtn(
                  label: e.value,
                  selected: st.currentMealType == e.key,
                  onTap: () => st.setMealType(e.key),
                ),
            ],
          ),
          const SizedBox(height: 16),
          PrimaryButton(label: 'إضافة', onPressed: _add),
        ],
      ),
    );
  }
}
