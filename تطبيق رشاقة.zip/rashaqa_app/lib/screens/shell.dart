import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../state/app_state.dart';
import '../theme.dart';
import 'add_meal.dart';
import 'home.dart';
import 'more.dart';
import 'reports.dart';

/// الإطار الرئيسي: أربع تبويبات سفلية.
class MainShell extends StatelessWidget {
  const MainShell({super.key});

  @override
  Widget build(BuildContext context) {
    final st = context.watch<AppState>();
    return Scaffold(
      body: IndexedStack(
        index: st.tabIndex,
        children: const [
          HomeScreen(),
          AddMealScreen(),
          ReportsScreen(),
          MoreScreen(),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: st.tabIndex,
        onDestinationSelected: st.setTab,
        backgroundColor: C.nav,
        indicatorColor: C.greenDark,
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.home_outlined, color: C.muted),
            selectedIcon: Icon(Icons.home, color: C.green),
            label: 'الرئيسية',
          ),
          NavigationDestination(
            icon: Icon(Icons.restaurant_menu_outlined, color: C.muted),
            selectedIcon: Icon(Icons.restaurant_menu, color: C.green),
            label: 'الوجبات',
          ),
          NavigationDestination(
            icon: Icon(Icons.bar_chart_outlined, color: C.muted),
            selectedIcon: Icon(Icons.bar_chart, color: C.green),
            label: 'التقارير',
          ),
          NavigationDestination(
            icon: Icon(Icons.more_horiz, color: C.muted),
            selectedIcon: Icon(Icons.more_horiz, color: C.green),
            label: 'المزيد',
          ),
        ],
      ),
    );
  }
}
