import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models.dart';
import '../state/app_state.dart';
import '../theme.dart';
import '../utils/format.dart';
import '../widgets/common.dart';
import 'food_edit.dart';

/// مكتبة الأطعمة: بحث عربي + تصنيفات + أطعمتي.
class SearchScreen extends StatefulWidget {
  final String initialQuery;
  final String initialCategory;

  const SearchScreen({
    super.key,
    this.initialQuery = '',
    this.initialCategory = 'الكل',
  });

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  late final TextEditingController _c;
  late String _cat;

  @override
  void initState() {
    super.initState();
    _c = TextEditingController(text: widget.initialQuery);
    _cat = widget.initialCategory;
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final st = context.watch<AppState>();
    final cats = <String>['الكل', 'أطعمتي', ...st.repo.categories];
    final results = st.searchFoods(_c.text, _cat);

    return Scaffold(
      appBar: AppBar(title: const Text('مكتبة الأطعمة')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
            child: TextBox(
              controller: _c,
              hint: 'ابحث: دجاج، أرز، تمر، تونة...',
              prefix: Icons.search,
              onChanged: (_) => setState(() {}),
              suffix: IconButton(
                tooltip: 'مسح البحث',
                icon: const Icon(Icons.close, color: C.muted),
                onPressed: () {
                  _c.clear();
                  setState(() => _cat = 'الكل');
                },
              ),
            ),
          ),
          SizedBox(
            height: 48,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: cats.length,
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemBuilder: (_, i) => ChoiceBtn(
                label: cats[i],
                selected: _cat == cats[i],
                onTap: () => setState(() => _cat = cats[i]),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
            child: Align(
              alignment: AlignmentDirectional.centerStart,
              child: Text(
                '${results.length} طعام · القيم لكل 100 غرام · "تقديري" = قيمة تقريبية تحتاج مراجعة',
                style: const TextStyle(fontSize: 12, color: C.muted),
              ),
            ),
          ),
          Expanded(
            child: results.isEmpty
                ? const Center(
                    child: Text('لا توجد نتائج مطابقة لبحثك',
                        style: TextStyle(color: C.muted)))
                : ListView.separated(
                    padding: const EdgeInsets.fromLTRB(16, 4, 16, 12),
                    itemCount: results.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 8),
                    itemBuilder: (_, i) => _FoodTile(food: results[i]),
                  ),
          ),
          SafeArea(
            top: false,
            child: Container(
              width: double.infinity,
              color: C.nav,
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 10),
              child: AppCard(
                color: C.greenDark,
                borderColor: C.greenBorder,
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                onTap: () => Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => const FoodEditScreen()),
                ),
                child: Row(
                  children: [
                    const IconBox(
                        icon: Icons.add, fg: C.green, bg: C.bg, size: 40),
                    const SizedBox(width: 12),
                    const Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('لم تجد طعامك؟',
                              style: TextStyle(
                                  fontSize: 15, fontWeight: FontWeight.w700)),
                          Text('أضف طعاماً مخصصاً بقيمه الغذائية',
                              style: TextStyle(
                                  fontSize: 12, color: Color(0xFFB7CCC0))),
                        ],
                      ),
                    ),
                    const Icon(Icons.chevron_right, color: C.muted),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _FoodTile extends StatelessWidget {
  final Food food;
  const _FoodTile({required this.food});

  @override
  Widget build(BuildContext context) {
    final subtitle = food.estimate ? '${food.category} · تقديري' : food.category;
    return AppCard(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      onTap: () => Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => FoodEditScreen(food: food)),
      ),
      child: Row(
        children: [
          const IconBox(
              icon: Icons.restaurant, fg: C.green, bg: C.greenDark, size: 44, radius: 22),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(food.name,
                    style: const TextStyle(
                        fontSize: 16, fontWeight: FontWeight.w700)),
                Text(subtitle,
                    style: const TextStyle(fontSize: 11, color: C.muted)),
                const SizedBox(height: 2),
                Wrap(
                  spacing: 10,
                  children: [
                    Text('بروتين ${fmtNum(food.protein)} غ',
                        style: const TextStyle(fontSize: 12, color: C.protein)),
                    Text('كارب ${fmtNum(food.carbs)} غ',
                        style: const TextStyle(fontSize: 12, color: C.carbs)),
                    Text('دهون ${fmtNum(food.fat)} غ',
                        style: const TextStyle(fontSize: 12, color: C.fat)),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(fmtInt(food.kcal),
                  style: const TextStyle(
                      fontSize: 20, fontWeight: FontWeight.w800, color: C.green)),
              const Text('سعرة', style: TextStyle(fontSize: 11, color: C.muted)),
            ],
          ),
          if (food.custom && food.id != null)
            IconButton(
              tooltip: 'حذف من أطعمتي',
              icon: const Icon(Icons.delete_outline, color: C.danger),
              onPressed: () => context.read<AppState>().deleteUserFood(food.id!),
            ),
        ],
      ),
    );
  }
}
