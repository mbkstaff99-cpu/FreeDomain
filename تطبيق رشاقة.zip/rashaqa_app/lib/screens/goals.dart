import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models.dart';
import '../state/app_state.dart';
import '../theme.dart';
import '../utils/format.dart';
import '../utils/nutrition.dart';
import '../widgets/common.dart';

/// الوزن والطول والعمر + الاحتياج اليومي. كل الأرقام حرة التعديل بلا حدود.
class GoalsScreen extends StatefulWidget {
  const GoalsScreen({super.key});

  @override
  State<GoalsScreen> createState() => _GoalsScreenState();
}

class _GoalsScreenState extends State<GoalsScreen> {
  late final TextEditingController _weight;
  late final TextEditingController _height;
  late final TextEditingController _age;
  late final TextEditingController _k;
  late final TextEditingController _p;
  late final TextEditingController _c;
  late final TextEditingController _f;
  late String _sex;
  late String _activity;
  late String _goal;

  @override
  void initState() {
    super.initState();
    final st = context.read<AppState>();
    final pr = st.profile;
    final t = st.targets;
    _weight = TextEditingController(text: fmtNum(pr.weight));
    _height = TextEditingController(text: fmtNum(pr.height));
    _age = TextEditingController(text: pr.age.toString());
    _k = TextEditingController(text: fmtNum(t.kcal));
    _p = TextEditingController(text: fmtNum(t.protein));
    _c = TextEditingController(text: fmtNum(t.carbs));
    _f = TextEditingController(text: fmtNum(t.fat));
    _sex = pr.sex;
    _activity = pr.activity;
    _goal = pr.goal;
  }

  @override
  void dispose() {
    for (final c in [_weight, _height, _age, _k, _p, _c, _f]) {
      c.dispose();
    }
    super.dispose();
  }

  Profile _profile(AppState st) => st.profile.copyWith(
        weight: parseNum(_weight.text),
        height: parseNum(_height.text),
        age: parseNum(_age.text).round(),
        sex: _sex,
        activity: _activity,
        goal: _goal,
      );

  void _bump(TextEditingController c, double d) {
    final v = parseNum(c.text) + d;
    setState(() => c.text = fmtNum(v < 0 ? 0 : v));
  }

  void _autoCalc() {
    final st = context.read<AppState>();
    final t = calcTargets(_profile(st));
    setState(() {
      _k.text = fmtNum(t.kcal);
      _p.text = fmtNum(t.protein);
      _c.text = fmtNum(t.carbs);
      _f.text = fmtNum(t.fat);
    });
  }

  Future<void> _save() async {
    final st = context.read<AppState>();
    final messenger = ScaffoldMessenger.of(context);
    await st.saveProfile(
      _profile(st),
      Targets(
        kcal: parseNum(_k.text),
        protein: parseNum(_p.text),
        carbs: parseNum(_c.text),
        fat: parseNum(_f.text),
      ),
    );
    if (!mounted) return;
    Navigator.of(context).pop();
    messenger.showSnackBar(const SnackBar(content: Text('تم حفظ بياناتك وأهدافك')));
  }

  Widget _stepRow(String label, String unit, TextEditingController c) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Expanded(
            child: Text(label, style: const TextStyle(fontSize: 15, color: C.muted)),
          ),
          IconButton.outlined(
            tooltip: 'زيادة $label',
            onPressed: () => _bump(c, 1),
            icon: const Icon(Icons.add, size: 18),
          ),
          const SizedBox(width: 6),
          NumBox(controller: c, width: 76, fontSize: 18, semanticLabel: label, onChanged: (_) => setState(() {})),
          const SizedBox(width: 6),
          IconButton.outlined(
            tooltip: 'إنقاص $label',
            onPressed: () => _bump(c, -1),
            icon: const Icon(Icons.remove, size: 18),
          ),
          SizedBox(
            width: 34,
            child: Text(unit,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 12, color: C.muted)),
          ),
        ],
      ),
    );
  }

  Widget _chips(String title, Map<String, String> options, String current,
      ValueChanged<String> onPick) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        children: [
          SizedBox(
            width: 58,
            child: Text(title, style: const TextStyle(fontSize: 14, color: C.muted)),
          ),
          Expanded(
            child: Row(
              children: [
                for (final e in options.entries) ...[
                  Expanded(
                    child: ChoiceBtn(
                      label: e.value,
                      selected: current == e.key,
                      fontSize: 13,
                      padding: const EdgeInsets.symmetric(horizontal: 4),
                      onTap: () => setState(() => onPick(e.key)),
                    ),
                  ),
                  if (e.key != options.keys.last) const SizedBox(width: 6),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _targetRow({
    required String label,
    required String unit,
    required IconData icon,
    required Color fg,
    required Color bg,
    required TextEditingController ctrl,
    Color? border,
  }) {
    return AppCard(
      padding: const EdgeInsets.fromLTRB(10, 8, 12, 8),
      child: Row(
        children: [
          IconBox(icon: icon, fg: fg, bg: bg, size: 34, radius: 11),
          const SizedBox(width: 10),
          Expanded(
            child: Text(label, style: const TextStyle(fontSize: 15, color: C.muted)),
          ),
          NumBox(
            controller: ctrl,
            color: fg,
            width: 100,
            semanticLabel: label,
            borderColor: border ?? C.border,
            onChanged: (_) => setState(() {}),
          ),
          SizedBox(
            width: 38,
            child: Text(unit,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 12, color: C.muted)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final calcK = (4 * parseNum(_p.text) + 4 * parseNum(_c.text) + 9 * parseNum(_f.text)).round();
    return Scaffold(
      appBar: AppBar(title: const Text('أهدافك وبياناتك')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 16),
        children: [
          const Text('معلوماتك الشخصية',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          AppCard(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            child: Column(
              children: [
                _stepRow('الوزن', 'كغ', _weight),
                const Divider(height: 1),
                _stepRow('الطول', 'سم', _height),
                const Divider(height: 1),
                _stepRow('العمر', 'سنة', _age),
              ],
            ),
          ),
          const SizedBox(height: 14),
          _chips('الجنس', const {'m': 'ذكر', 'f': 'أنثى'}, _sex, (v) => _sex = v),
          _chips('النشاط', activityNames, _activity, (v) => _activity = v),
          _chips('الهدف', goalNames, _goal, (v) => _goal = v),
          const SizedBox(height: 4),
          SoftGreenButton(label: 'احسب احتياجي تلقائياً (اختياري)', onPressed: _autoCalc),
          const SizedBox(height: 20),
          const Text('أهدافك اليومية (عدّلها كما تشاء)',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          _targetRow(
              label: 'السعرات الحرارية',
              unit: 'سعرة',
              icon: Icons.local_fire_department_outlined,
              fg: C.green,
              bg: C.greenDark,
              ctrl: _k,
              border: C.greenBorder),
          const SizedBox(height: 8),
          _targetRow(
              label: 'البروتين',
              unit: 'غرام',
              icon: Icons.hexagon_outlined,
              fg: C.protein,
              bg: C.proteinBg,
              ctrl: _p),
          const SizedBox(height: 8),
          _targetRow(
              label: 'الكربوهيدرات',
              unit: 'غرام',
              icon: Icons.grain,
              fg: C.carbs,
              bg: C.carbsBg,
              ctrl: _c),
          const SizedBox(height: 8),
          _targetRow(
              label: 'الدهون',
              unit: 'غرام',
              icon: Icons.water_drop_outlined,
              fg: C.fat,
              bg: C.fatBg,
              ctrl: _f),
          const SizedBox(height: 10),
          Text(
            'كل الأرقام حرة التعديل بلا حدود. السعرات المحسوبة من الجرامات الحالية: ${fmtInt(calcK)} سعرة (للمعلومة فقط).',
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 12, color: C.muted, height: 1.6),
          ),
        ],
      ),
      bottomNavigationBar: SafeArea(
        child: Container(
          color: C.nav,
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 10),
          child: PrimaryButton(label: 'حفظ', onPressed: _save),
        ),
      ),
    );
  }
}
