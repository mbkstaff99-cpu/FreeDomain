import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../state/app_state.dart';
import '../theme.dart';
import '../utils/format.dart';
import '../widgets/common.dart';
import 'search.dart';

/// تفاصيل وجبة (فطور/غداء/عشاء/وجبة خفيفة) في اليوم المحدد.
class MealDetailsScreen extends StatelessWidget {
  final String mealType;
  const MealDetailsScreen({super.key, required this.mealType});

  Widget _tile(String label, String value, Color color) {
    return Expanded(
      child: AppCard(
        padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 12),
        child: Column(
          children: [
            Text(label, style: const TextStyle(fontSize: 11, color: C.muted)),
            const SizedBox(height: 4),
            Text(value,
                style: TextStyle(
                    fontSize: 20, fontWeight: FontWeight.w800, color: color)),
          ],
        ),
      ),
    );
  }

  Future<void> _confirmDelete(BuildContext context, AppState st) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: C.card,
        title: const Text('حذف الوجبة؟'),
        content: const Text('سيتم حذف كل الأطعمة في هذه الوجبة لهذا اليوم.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.of(ctx).pop(false),
              child: const Text('إلغاء')),
          TextButton(
              onPressed: () => Navigator.of(ctx).pop(true),
              child: const Text('حذف', style: TextStyle(color: C.danger))),
        ],
      ),
    );
    if (ok == true) {
      await st.deleteMeal(mealType);
      if (context.mounted) Navigator.of(context).pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    final st = context.watch<AppState>();
    final items = st.byMeal[mealType] ?? const [];
    final tot = st.mealTotals(mealType);

    return Scaffold(
      appBar: AppBar(title: const Text('تفاصيل الوجبة')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
        children: [
          AppCard(
            child: Row(
              children: [
                const IconBox(
                    icon: Icons.restaurant,
                    fg: C.fat,
                    bg: C.fatBg,
                    size: 64,
                    radius: 18),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(mealTypeNames[mealType] ?? '',
                          style: const TextStyle(
                              fontSize: 20, fontWeight: FontWeight.w800)),
                      const SizedBox(height: 4),
                      Text(arDateLong(st.selectedDate),
                          style: const TextStyle(fontSize: 13, color: C.muted)),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              _tile('السعرات', fmtInt(tot.kcal), C.green),
              const SizedBox(width: 8),
              _tile('البروتين', fmtNum(tot.protein), C.protein),
              const SizedBox(width: 8),
              _tile('الكربوهيدرات', fmtNum(tot.carbs), C.carbs),
              const SizedBox(width: 8),
              _tile('الدهون', fmtNum(tot.fat), C.fat),
            ],
          ),
          const SizedBox(height: 12),
          AppCard(
            padding: const EdgeInsets.fromLTRB(14, 12, 6, 6),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('المكونات',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                const SizedBox(height: 6),
                if (items.isEmpty)
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 16),
                    child: Text('لا توجد أطعمة في هذه الوجبة بعد',
                        style: TextStyle(color: C.muted)),
                  ),
                for (final e in items) ...[
                  const Divider(height: 1),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 6),
                    child: Row(
                      children: [
                        const IconBox(
                            icon: Icons.restaurant,
                            fg: C.green,
                            bg: C.greenDark,
                            size: 40,
                            radius: 20),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(e.name,
                                  style: const TextStyle(
                                      fontSize: 15, fontWeight: FontWeight.w700)),
                              Text('${fmtNum(e.grams)} غ',
                                  style: const TextStyle(
                                      fontSize: 12, color: C.muted)),
                            ],
                          ),
                        ),
                        Text('${fmtInt(e.kcal)} سعرة',
                            style: const TextStyle(fontSize: 14, color: C.muted)),
                        IconButton(
                          tooltip: 'حذف',
                          icon: const Icon(Icons.delete_outline, color: C.danger),
                          onPressed: () {
                            if (e.id != null) st.deleteEntry(e.id!);
                          },
                        ),
                      ],
                    ),
                  ),
                ],
              ],
            ),
          ),
          const SizedBox(height: 16),
          OutlinedButton.icon(
            onPressed: () {
              st.setMealType(mealType);
              Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => const SearchScreen()));
            },
            style: OutlinedButton.styleFrom(
              minimumSize: const Size.fromHeight(54),
              foregroundColor: C.green,
              side: const BorderSide(color: C.greenBorder),
              shape:
                  RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
            ),
            icon: const Icon(Icons.add),
            label: const Text('إضافة طعام لهذه الوجبة',
                style: TextStyle(fontWeight: FontWeight.w700)),
          ),
          const SizedBox(height: 10),
          OutlinedButton.icon(
            onPressed: items.isEmpty ? null : () => _confirmDelete(context, st),
            style: OutlinedButton.styleFrom(
              minimumSize: const Size.fromHeight(54),
              foregroundColor: C.danger,
              backgroundColor: C.dangerBg,
              side: const BorderSide(color: C.dangerBorder),
              shape:
                  RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
            ),
            icon: const Icon(Icons.delete_outline),
            label: const Text('حذف الوجبة',
                style: TextStyle(fontWeight: FontWeight.w700)),
          ),
        ],
      ),
    );
  }
}
