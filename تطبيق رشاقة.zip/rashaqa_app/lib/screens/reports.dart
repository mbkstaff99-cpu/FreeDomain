import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models.dart';
import '../state/app_state.dart';
import '../theme.dart';
import '../utils/format.dart';
import '../widgets/common.dart';

class Bucket {
  final String label;
  final Totals totals;
  const Bucket(this.label, this.totals);
}

/// التقارير: أسبوعي / شهري (متوسط كل أسبوع) / مخصص (اختيار فترة).
/// الأعمدة = نسبة الإنجاز من الهدف اليومي لكل من السعرات والبروتين والكربوهيدرات.
class ReportsScreen extends StatefulWidget {
  const ReportsScreen({super.key});

  @override
  State<ReportsScreen> createState() => _ReportsScreenState();
}

class _ReportsScreenState extends State<ReportsScreen> {
  String _period = 'week';
  DateTime _anchor = DateTime.now();
  DateTimeRange? _custom;
  int _sel = -1;
  String _key = '';
  Future<List<Bucket>>? _future;

  DateTime _d(DateTime x) => DateTime(x.year, x.month, x.day);

  (DateTime, DateTime) _range() {
    if (_period == 'custom' && _custom != null) {
      var from = _d(_custom!.start);
      final to = _d(_custom!.end);
      if (to.difference(from).inDays > 30) {
        from = to.subtract(const Duration(days: 30));
      }
      return (from, to);
    }
    final to = _d(_anchor);
    return (to.subtract(const Duration(days: 6)), to);
  }

  Future<List<Bucket>> _load(AppState st) async {
    if (_period == 'month') {
      final first = DateTime(_anchor.year, _anchor.month, 1);
      final last = DateTime(_anchor.year, _anchor.month + 1, 0);
      final days = await st.dailyTotalsRange(first, last);
      final out = <Bucket>[];
      for (var i = 0; i < days.length; i += 7) {
        final chunk = days
            .sublist(i, math.min(i + 7, days.length))
            .where((e) => e.value.kcal > 0)
            .toList();
        var t = Totals.zero;
        for (final e in chunk) {
          t = t + e.value;
        }
        final n = chunk.length;
        out.add(Bucket(
          'الأسبوع ${i ~/ 7 + 1}',
          n == 0 ? Totals.zero : Totals(t.kcal / n, t.protein / n, t.carbs / n, t.fat / n),
        ));
      }
      return out;
    }
    if (_period == 'custom' && _custom == null) return const [];
    final r = _range();
    final days = await st.dailyTotalsRange(r.$1, r.$2);
    return days.map((e) => Bucket(arWeekdays[e.key.weekday - 1], e.value)).toList();
  }

  String _rangeLabel() {
    if (_period == 'month') return '${arMonths[_anchor.month - 1]} ${_anchor.year}';
    if (_period == 'custom' && _custom == null) return 'اختر الفترة';
    final r = _range();
    final a = r.$1;
    final b = r.$2;
    if (a.month == b.month && a.year == b.year) {
      return '${a.day} - ${b.day} ${arMonths[b.month - 1]} ${b.year}';
    }
    return '${a.day} ${arMonths[a.month - 1]} - ${b.day} ${arMonths[b.month - 1]} ${b.year}';
  }

  void _shift(int dir) {
    setState(() {
      _sel = -1;
      if (_period == 'month') {
        _anchor = DateTime(_anchor.year, _anchor.month + dir, 1);
      } else {
        _anchor = _anchor.add(Duration(days: 7 * dir));
      }
    });
  }

  Future<void> _pickCustom() async {
    final picked = await showDateRangePicker(
      context: context,
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
      initialDateRange: _custom,
    );
    if (picked != null) {
      setState(() {
        _custom = picked;
        _sel = -1;
      });
    }
  }

  void _setPeriod(String p) {
    setState(() {
      _period = p;
      _sel = -1;
    });
    if (p == 'custom' && _custom == null) _pickCustom();
  }

  @override
  Widget build(BuildContext context) {
    final st = context.watch<AppState>();
    final key =
        '$_period|${dateKey(_anchor)}|${_custom?.start}|${_custom?.end}|${st.dataVersion}';
    if (key != _key) {
      _key = key;
      _future = _load(st);
    }
    final g = st.targets;

    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
        children: [
          const SizedBox(
            height: 44,
            child: Center(
              child: Text('التقارير',
                  style: TextStyle(fontSize: 19, fontWeight: FontWeight.w700)),
            ),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              for (final p in const [
                ['week', 'أسبوعي'],
                ['month', 'شهري'],
                ['custom', 'مخصص'],
              ]) ...[
                Expanded(
                  child: ChoiceBtn(
                    label: p[1],
                    selected: _period == p[0],
                    onTap: () => _setPeriod(p[0]),
                  ),
                ),
                if (p[0] != 'custom') const SizedBox(width: 8),
              ],
            ],
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              IconButton(
                tooltip: 'الفترة السابقة',
                onPressed: _period == 'custom' ? null : () => _shift(-1),
                icon: const Icon(Icons.chevron_left, color: C.muted),
              ),
              TextButton(
                onPressed: _period == 'custom' ? _pickCustom : null,
                child: Text(_rangeLabel(),
                    style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                        color: C.text)),
              ),
              IconButton(
                tooltip: 'الفترة التالية',
                onPressed: _period == 'custom' ? null : () => _shift(1),
                icon: const Icon(Icons.chevron_right, color: C.muted),
              ),
            ],
          ),
          FutureBuilder<List<Bucket>>(
            future: _future,
            builder: (context, snap) {
              if (snap.connectionState != ConnectionState.done) {
                return const SizedBox(
                    height: 260,
                    child: Center(child: CircularProgressIndicator()));
              }
              final buckets = snap.data ?? const <Bucket>[];
              if (buckets.isEmpty) {
                return const SizedBox(
                  height: 200,
                  child: Center(
                    child: Text('اختر فترة لعرض التقرير',
                        style: TextStyle(color: C.muted)),
                  ),
                );
              }
              final sel = (_sel >= 0 && _sel < buckets.length)
                  ? _sel
                  : buckets.length - 1;
              final s = buckets[sel];
              final prefix = _period == 'month' ? 'متوسط يومي · ' : 'القيم ليوم ';
              return Column(
                children: [
                  _BarChart(
                    buckets: buckets,
                    targets: g,
                    selected: sel,
                    onSelect: (i) => setState(() => _sel = i),
                  ),
                  const SizedBox(height: 8),
                  const Wrap(
                    alignment: WrapAlignment.center,
                    spacing: 14,
                    children: [
                      _Legend(color: C.green, label: 'السعرات'),
                      _Legend(color: C.protein, label: 'البروتين'),
                      _Legend(color: C.carbs, label: 'الكربوهيدرات'),
                      Text('· نسبة من الهدف',
                          style: TextStyle(fontSize: 12, color: C.muted)),
                    ],
                  ),
                  const SizedBox(height: 14),
                  AppCard(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(top: 6),
                          child: Text('$prefix${s.label}',
                              style: const TextStyle(fontSize: 13, color: C.muted)),
                        ),
                        InfoRow(
                            label: 'السعرات الحرارية',
                            value: '${fmtInt(s.totals.kcal)} / ${fmtInt(g.kcal)}',
                            valueColor: C.green),
                        const Divider(height: 1),
                        InfoRow(
                            label: 'البروتين',
                            value: '${fmtNum(s.totals.protein)} / ${fmtNum(g.protein)} غ',
                            valueColor: C.protein),
                        const Divider(height: 1),
                        InfoRow(
                            label: 'الكربوهيدرات',
                            value: '${fmtNum(s.totals.carbs)} / ${fmtNum(g.carbs)} غ',
                            valueColor: C.carbs),
                        const Divider(height: 1),
                        InfoRow(
                            label: 'الدهون',
                            value: '${fmtNum(s.totals.fat)} / ${fmtNum(g.fat)} غ',
                            valueColor: C.fat),
                      ],
                    ),
                  ),
                ],
              );
            },
          ),
        ],
      ),
    );
  }
}

class _Legend extends StatelessWidget {
  final Color color;
  final String label;
  const _Legend({required this.color, required this.label});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 8,
          height: 8,
          decoration: BoxDecoration(color: color, shape: BoxShape.circle),
        ),
        const SizedBox(width: 5),
        Text(label, style: const TextStyle(fontSize: 12, color: C.muted)),
      ],
    );
  }
}

class _BarChart extends StatelessWidget {
  final List<Bucket> buckets;
  final Targets targets;
  final int selected;
  final ValueChanged<int> onSelect;

  const _BarChart({
    required this.buckets,
    required this.targets,
    required this.selected,
    required this.onSelect,
  });

  static const double _h = 140; // ارتفاع منطقة الأعمدة

  double _barH(double value, double target) {
    if (value <= 0 || target <= 0) return 0;
    return math.max(3.0, math.min(1.0, value / target) * _h);
  }

  Widget _bar(double h, double w, Color c) => Container(
        width: w,
        height: h,
        decoration: BoxDecoration(
          color: c,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(3)),
        ),
      );

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 176,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 36,
            child: Stack(
              children: const [
                Positioned(
                    top: 0,
                    right: 0,
                    child: Text('100%', style: TextStyle(fontSize: 11, color: C.muted))),
                Positioned(
                    top: 71,
                    right: 0,
                    child: Text('50%', style: TextStyle(fontSize: 11, color: C.muted))),
                Positioned(
                    top: 141,
                    right: 0,
                    child: Text('0', style: TextStyle(fontSize: 11, color: C.muted))),
              ],
            ),
          ),
          Expanded(
            child: LayoutBuilder(
              builder: (context, cons) {
                final n = buckets.length;
                final colW = cons.maxWidth / n;
                final bw = ((colW - 10) / 3).clamp(3.0, 14.0);
                return Stack(
                  children: [
                    for (final top in const [8.0, 78.0, 148.0])
                      Positioned(
                        top: top,
                        left: 0,
                        right: 0,
                        child: Container(height: 1, color: C.ring),
                      ),
                    Positioned.fill(
                      top: 8,
                      child: Row(
                        children: [
                          for (var i = 0; i < n; i++)
                            Expanded(
                              child: Semantics(
                                button: true,
                                label:
                                    '${buckets[i].label}: ${fmtInt(buckets[i].totals.kcal)} سعرة',
                                child: InkWell(
                                  borderRadius: BorderRadius.circular(10),
                                  onTap: () => onSelect(i),
                                  child: DecoratedBox(
                                    decoration: BoxDecoration(
                                      color: i == selected ? C.card : Colors.transparent,
                                      borderRadius: BorderRadius.circular(10),
                                      border: Border.all(
                                          color: i == selected ? C.border : Colors.transparent),
                                    ),
                                    child: Column(
                                      children: [
                                        SizedBox(
                                          height: _h,
                                          child: Row(
                                            crossAxisAlignment: CrossAxisAlignment.end,
                                            mainAxisAlignment: MainAxisAlignment.center,
                                            children: [
                                              _bar(_barH(buckets[i].totals.kcal, targets.kcal), bw, C.green),
                                              const SizedBox(width: 2),
                                              _bar(_barH(buckets[i].totals.protein, targets.protein), bw, C.protein),
                                              const SizedBox(width: 2),
                                              _bar(_barH(buckets[i].totals.carbs, targets.carbs), bw, C.carbs),
                                            ],
                                          ),
                                        ),
                                        SizedBox(
                                          height: 28,
                                          child: Center(
                                            child: FittedBox(
                                              fit: BoxFit.scaleDown,
                                              child: Text(buckets[i].label,
                                                  style: const TextStyle(
                                                      fontSize: 11, color: C.muted)),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                        ],
                      ),
                    ),
                  ],
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
