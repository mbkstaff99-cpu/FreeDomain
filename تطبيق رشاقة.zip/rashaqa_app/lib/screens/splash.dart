import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../state/app_state.dart';
import '../theme.dart';
import 'shell.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _go();
  }

  Future<void> _go() async {
    final st = context.read<AppState>();
    await Future.delayed(const Duration(milliseconds: 1600));
    while (!st.ready) {
      await Future.delayed(const Duration(milliseconds: 100));
      if (!mounted) return;
    }
    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => const MainShell()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            const Spacer(flex: 3),
            Container(
              width: 120,
              height: 120,
              decoration: const BoxDecoration(
                color: C.greenDark,
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.eco_rounded, color: C.green, size: 64),
            ),
            const SizedBox(height: 20),
            const Text('رشاقة',
                style: TextStyle(fontSize: 64, fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            const Text('هدفك .. أبسط',
                style: TextStyle(fontSize: 18, color: C.muted)),
            const Spacer(flex: 3),
            const SizedBox(
              width: 28,
              height: 6,
              child: DecoratedBox(
                decoration: BoxDecoration(
                  color: C.green,
                  borderRadius: BorderRadius.all(Radius.circular(3)),
                ),
              ),
            ),
            const SizedBox(height: 20),
            const Text('معك نحو حياة أكثر صحة',
                style: TextStyle(fontSize: 16, color: C.muted)),
            const SizedBox(height: 48),
          ],
        ),
      ),
    );
  }
}
