import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../state/app_state.dart';
import '../theme.dart';
import '../utils/format.dart';
import '../widgets/common.dart';
import 'food_edit.dart';
import 'search.dart';

/// تبويب "الوجبات": طرق إضافة الطعام.
class AddMealScreen extends StatefulWidget {
  const AddMealScreen({super.key});

  @override
  State<AddMealScreen> createState() => _AddMealScreenState();
}

class _AddMealScreenState extends State<AddMealScreen> {
  final TextEditingController _q = TextEditingController();

  @override
  void dispose() {
    _q.dispose();
    super.dispose();
  }

  void _openSearch({String query = '', String category = 'الكل'}) {
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => SearchScreen(initialQuery: query, initialCategory: category),
    ));
  }

  void _comingSoon() {
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: C.card,
        title: const Text('قريباً'),
        content: const Text(
            'التعرف على الطعام بالكاميرا سيُضاف في نسخة لاحقة (يحتاج ربطاً بنموذج ذكاء اصطناعي يقرأ الصور).'),
        actions: [
          TextButton(
              onPressed: () => Navigator.of(ctx).pop(), child: const Text('حسناً')),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final st = context.watch<AppState>();
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
        children: [
          const SizedBox(
            height: 44,
            child: Center(
              child: Text('إضافة وجبة',
                  style: TextStyle(fontSize: 19, fontWeight: FontWeight.w700)),
            ),
          ),
          const SizedBox(height: 8),
          const Text('أضف إلى:', style: TextStyle(fontSize: 14, color: C.muted)),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (final e in mealTypeNames.entries)
                ChoiceBtn(
                  label: e.value,
                  selected: st.currentMealType == e.key,
                  onTap: () => st.setMealType(e.key),
                ),
            ],
          ),
          const SizedBox(height: 16),
          TextBox(
            controller: _q,
            hint: 'ابحث عن طعام أو وجبة...',
            prefix: Icons.search,
            onSubmitted: (v) => _openSearch(query: v),
          ),
          const SizedBox(height: 16),
          _Option(
            icon: Icons.add,
            fg: C.green,
            bg: C.greenDark,
            title: 'إضافة طعام يدوي',
            subtitle: 'إدخال القيم الغذائية يدوياً',
            onTap: () => Navigator.of(context)
                .push(MaterialPageRoute(builder: (_) => const FoodEditScreen())),
          ),
          const SizedBox(height: 12),
          _Option(
            icon: Icons.storage_outlined,
            fg: C.protein,
            bg: C.proteinBg,
            title: 'من مكتبة الأطعمة',
            subtitle: 'البحث عن طعام من قاعدة البيانات',
            onTap: () => _openSearch(),
          ),
          const SizedBox(height: 12),
          _Option(
            icon: Icons.bookmark_border,
            fg: C.carbs,
            bg: C.carbsBg,
            title: 'أطعمتي المحفوظة',
            subtitle: 'الأطعمة التي أضفتها بنفسك',
            onTap: () => _openSearch(category: 'أطعمتي'),
          ),
          const SizedBox(height: 12),
          _Option(
            icon: Icons.photo_camera_outlined,
            fg: C.fat,
            bg: C.fatBg,
            title: 'صورة الطعام',
            subtitle: 'استخدام الكاميرا للتعرف على الطعام (قريباً)',
            onTap: _comingSoon,
          ),
        ],
      ),
    );
  }
}

class _Option extends StatelessWidget {
  final IconData icon;
  final Color fg;
  final Color bg;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  const _Option({
    required this.icon,
    required this.fg,
    required this.bg,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return AppCard(
      onTap: onTap,
      child: Row(
        children: [
          IconBox(icon: icon, fg: fg, bg: bg, size: 48, radius: 14),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    style: const TextStyle(
                        fontSize: 17, fontWeight: FontWeight.w700)),
                const SizedBox(height: 2),
                Text(subtitle,
                    style: const TextStyle(fontSize: 13, color: C.muted)),
              ],
            ),
          ),
          const Icon(Icons.chevron_right, color: C.muted),
        ],
      ),
    );
  }
}
