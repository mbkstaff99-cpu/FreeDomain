import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../state/app_state.dart';
import '../theme.dart';
import '../utils/format.dart';
import '../widgets/common.dart';
import 'meal_details.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  Future<void> _pickDate(BuildContext context, AppState st) async {
    final d = await showDatePicker(
      context: context,
      initialDate: st.selectedDate,
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
    );
    if (d != null) await st.setDate(d);
  }

  @override
  Widget build(BuildContext context) {
    final st = context.watch<AppState>();
    final t = st.totals;
    final g = st.targets;
    final progress = g.kcal > 0 ? t.kcal / g.kcal : 0.0;
    final now = DateTime.now();
    final isToday = dateKey(st.selectedDate) == dateKey(now);
    final dayLabel = isToday
        ? 'اليوم'
        : (st.selectedDate.isBefore(now) ? 'يوم سابق' : 'يوم قادم');

    const mealStyle = <String, List<Color>>{
      'breakfast': [C.fat, C.fatBg],
      'lunch': [C.carbs, C.carbsBg],
      'dinner': [C.green, C.greenDark],
      'snack': [C.protein, C.proteinBg],
    };

    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
        children: [
          Row(
            children: [
              const Expanded(
                child: Text('رشاقة',
                    style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800)),
              ),
              IconButton(
                tooltip: 'الإعدادات',
                onPressed: () => st.setTab(3),
                icon: const Icon(Icons.settings_outlined, color: C.muted),
              ),
            ],
          ),
          const SizedBox(height: 8),
          AppCard(
            padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
            child: Row(
              children: [
                IconButton(
                  tooltip: 'اليوم السابق',
                  onPressed: () => st.shiftDay(-1),
                  icon: const Icon(Icons.chevron_left, color: C.muted),
                ),
                Expanded(
                  child: InkWell(
                    onTap: () => _pickDate(context, st),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 6),
                      child: Column(
                        children: [
                          Text(dayLabel,
                              style: const TextStyle(fontSize: 13, color: C.muted)),
                          Text(arDateLong(st.selectedDate),
                              style: const TextStyle(
                                  fontSize: 15, fontWeight: FontWeight.w700)),
                        ],
                      ),
                    ),
                  ),
                ),
                IconButton(
                  tooltip: 'اليوم التالي',
                  onPressed: () => st.shiftDay(1),
                  icon: const Icon(Icons.chevron_right, color: C.muted),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Center(
            child: SizedBox(
              width: 196,
              height: 196,
              child: CustomPaint(
                painter: RingPainter(progress),
                child: Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Text('السعرات الحرارية',
                          style: TextStyle(fontSize: 13, color: C.muted)),
                      Text(fmtInt(t.kcal),
                          style: const TextStyle(
                              fontSize: 42, fontWeight: FontWeight.w800, height: 1.1)),
                      Text('من ${fmtInt(g.kcal)}',
                          style: const TextStyle(fontSize: 14, color: C.muted)),
                    ],
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: MacroTile(
                  label: 'البروتين',
                  value: t.protein,
                  target: g.protein,
                  color: C.protein,
                  bg: C.proteinBg,
                  icon: Icons.hexagon_outlined,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: MacroTile(
                  label: 'الكربوهيدرات',
                  value: t.carbs,
                  target: g.carbs,
                  color: C.carbs,
                  bg: C.carbsBg,
                  icon: Icons.grain,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: MacroTile(
                  label: 'الدهون',
                  value: t.fat,
                  target: g.fat,
                  color: C.fat,
                  bg: C.fatBg,
                  icon: Icons.water_drop_outlined,
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          Row(
            children: [
              const Expanded(
                child: Text('الوجبات اليوم',
                    style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
              ),
              IconButton.filled(
                tooltip: 'إضافة وجبة',
                onPressed: () => st.setTab(1),
                style: IconButton.styleFrom(
                  backgroundColor: C.green,
                  foregroundColor: C.bg,
                  minimumSize: const Size(44, 44),
                ),
                icon: const Icon(Icons.add),
              ),
            ],
          ),
          const SizedBox(height: 8),
          for (final entry in mealTypeNames.entries) ...[
            _MealTile(
              mealType: entry.key,
              name: entry.value,
              fg: mealStyle[entry.key]![0],
              bg: mealStyle[entry.key]![1],
            ),
            const SizedBox(height: 8),
          ],
        ],
      ),
    );
  }
}

class _MealTile extends StatelessWidget {
  final String mealType;
  final String name;
  final Color fg;
  final Color bg;

  const _MealTile({
    required this.mealType,
    required this.name,
    required this.fg,
    required this.bg,
  });

  @override
  Widget build(BuildContext context) {
    final st = context.watch<AppState>();
    final items = st.byMeal[mealType] ?? const [];
    final kcal = st.mealTotals(mealType).kcal;
    final subtitle = items.isEmpty
        ? 'لم تضف شيئاً بعد'
        : '${fmtInt(kcal)} سعرة حرارية · ${items.length} أصناف';
    return AppCard(
      onTap: () => Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => MealDetailsScreen(mealType: mealType)),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      child: Row(
        children: [
          IconBox(
              icon: Icons.restaurant, fg: fg, bg: bg, size: 44, radius: 22),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(name,
                    style: const TextStyle(
                        fontSize: 16, fontWeight: FontWeight.w700)),
                Text(subtitle,
                    style: const TextStyle(fontSize: 13, color: C.muted)),
              ],
            ),
          ),
          const Icon(Icons.chevron_right, color: C.muted),
        ],
      ),
    );
  }
}
