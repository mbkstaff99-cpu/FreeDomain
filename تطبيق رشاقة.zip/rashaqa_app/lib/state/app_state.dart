import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../data/db.dart';
import '../data/food_repository.dart';
import '../models.dart';
import '../utils/format.dart';

/// الحالة المركزية للتطبيق (Provider + ChangeNotifier).
class AppState extends ChangeNotifier {
  final FoodRepository repo = FoodRepository();

  Profile profile = Profile.defaults();
  Targets targets = Targets.defaults();
  DateTime selectedDate = DateTime.now();
  String currentMealType = guessMealType();
  int tabIndex = 0;

  /// يزيد مع كل تغيير في السجل، لتعرف الشاشات متى تعيد تحميل بياناتها.
  int dataVersion = 0;
  bool ready = false;

  List<Entry> entries = [];
  List<Food> userFoods = [];

  String get dateStr => dateKey(selectedDate);

  Future<void> init() async {
    final prefs = await SharedPreferences.getInstance();
    profile = Profile.fromPrefs(prefs);
    targets = Targets.fromPrefs(prefs);
    await repo.load();
    userFoods = await AppDb.userFoods();
    entries = await AppDb.entriesForDate(dateStr);
    ready = true;
    notifyListeners();
  }

  // ───────── التنقل والتاريخ ─────────
  void setTab(int i) {
    tabIndex = i;
    notifyListeners();
  }

  void setMealType(String t) {
    currentMealType = t;
    notifyListeners();
  }

  Future<void> setDate(DateTime d) async {
    selectedDate = DateTime(d.year, d.month, d.day);
    entries = await AppDb.entriesForDate(dateStr);
    notifyListeners();
  }

  Future<void> shiftDay(int delta) =>
      setDate(selectedDate.add(Duration(days: delta)));

  // ───────── المجاميع ─────────
  Totals get totals {
    var t = Totals.zero;
    for (final e in entries) {
      t = t + Totals(e.kcal, e.protein, e.carbs, e.fat);
    }
    return t;
  }

  Map<String, List<Entry>> get byMeal {
    final m = <String, List<Entry>>{};
    for (final e in entries) {
      (m[e.mealType] ??= <Entry>[]).add(e);
    }
    return m;
  }

  Totals mealTotals(String mealType) {
    var t = Totals.zero;
    for (final e in entries.where((e) => e.mealType == mealType)) {
      t = t + Totals(e.kcal, e.protein, e.carbs, e.fat);
    }
    return t;
  }

  // ───────── السجل ─────────
  Future<void> addEntry(Entry e) async {
    await AppDb.insertEntry(e);
    // نعيد تحميل اليوم المعروض (قد يختلف عن تاريخ السجل المضاف).
    entries = await AppDb.entriesForDate(dateStr);
    dataVersion++;
    notifyListeners();
  }

  Future<void> deleteEntry(int id) async {
    await AppDb.deleteEntry(id);
    entries = await AppDb.entriesForDate(dateStr);
    dataVersion++;
    notifyListeners();
  }

  Future<void> deleteMeal(String mealType) async {
    await AppDb.deleteMeal(dateStr, mealType);
    entries = await AppDb.entriesForDate(dateStr);
    dataVersion++;
    notifyListeners();
  }

  /// مجاميع كل يوم بين تاريخين (شاملين)، مع أيام بلا بيانات = صفر.
  Future<List<MapEntry<DateTime, Totals>>> dailyTotalsRange(
      DateTime from, DateTime to) async {
    final map = await AppDb.dailyTotals(dateKey(from), dateKey(to));
    final out = <MapEntry<DateTime, Totals>>[];
    var d = DateTime(from.year, from.month, from.day);
    final end = DateTime(to.year, to.month, to.day);
    while (!d.isAfter(end)) {
      out.add(MapEntry(d, map[dateKey(d)] ?? Totals.zero));
      d = DateTime(d.year, d.month, d.day + 1);
    }
    return out;
  }

  // ───────── أطعمة المستخدم ─────────
  List<Food> searchFoods(String query, String category) =>
      repo.search(query, category: category, extra: userFoods);

  Future<void> addUserFood(Food f) async {
    await AppDb.insertUserFood(f);
    userFoods = await AppDb.userFoods();
    notifyListeners();
  }

  Future<void> deleteUserFood(int id) async {
    await AppDb.deleteUserFood(id);
    userFoods = await AppDb.userFoods();
    notifyListeners();
  }

  // ───────── الملف الشخصي والأهداف ─────────
  Future<void> saveProfile(Profile p, Targets t) async {
    profile = p;
    targets = t;
    final prefs = await SharedPreferences.getInstance();
    await p.save(prefs);
    await t.save(prefs);
    notifyListeners();
  }

  Future<void> clearAll() async {
    await AppDb.clearAll();
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    profile = Profile.defaults();
    targets = Targets.defaults();
    userFoods = [];
    entries = [];
    dataVersion++;
    notifyListeners();
  }
}
