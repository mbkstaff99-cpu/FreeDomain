const String _arDigits = '٠١٢٣٤٥٦٧٨٩';

/// يحوّل نصاً (يدعم الأرقام العربية والفاصلة العربية) إلى رقم. القيمة الفارغة = 0.
double parseNum(String s) {
  var t = s.trim().replaceAll(',', '.').replaceAll('٫', '.');
  for (var i = 0; i < _arDigits.length; i++) {
    t = t.replaceAll(_arDigits[i], i.toString());
  }
  return double.tryParse(t) ?? 0;
}

/// عدد صحيح بفواصل آلاف: 2500 -> 2,500
String fmtInt(num v) {
  final s = v.round().abs().toString();
  final buf = StringBuffer();
  for (var i = 0; i < s.length; i++) {
    if (i > 0 && (s.length - i) % 3 == 0) buf.write(',');
    buf.write(s[i]);
  }
  return (v < 0 ? '-' : '') + buf.toString();
}

/// رقم بخانة عشرية واحدة كحد أقصى: 8.50 -> 8.5 ، 33.0 -> 33
String fmtNum(double v) {
  final r = (v * 10).round() / 10;
  return r == r.roundToDouble() ? r.toStringAsFixed(0) : r.toStringAsFixed(1);
}

String dateKey(DateTime d) =>
    '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

const List<String> arMonths = [
  'يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
  'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر',
];

/// فهرس weekday-1 (الاثنين=0 ... الأحد=6)
const List<String> arWeekdays = [
  'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت', 'الأحد',
];

String arDateLong(DateTime d) =>
    '${arWeekdays[d.weekday - 1]}، ${d.day} ${arMonths[d.month - 1]} ${d.year}';

const Map<String, String> mealTypeNames = {
  'breakfast': 'الفطور',
  'lunch': 'الغداء',
  'dinner': 'العشاء',
  'snack': 'وجبة خفيفة',
};

const Map<String, String> goalNames = {
  'lose': 'خسارة وزن',
  'keep': 'ثبات الوزن',
  'gain': 'بناء عضلات',
};

const Map<String, String> activityNames = {
  'low': 'خفيف',
  'mid': 'متوسط',
  'high': 'عالٍ',
};

String guessMealType() {
  final h = DateTime.now().hour;
  if (h < 11) return 'breakfast';
  if (h < 16) return 'lunch';
  if (h < 21) return 'dinner';
  return 'snack';
}
