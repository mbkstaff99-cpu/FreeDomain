import '../models.dart';

/// حساب الاحتياج اليومي (معادلة Mifflin-St Jeor). تقدير أولي فقط،
/// ويمكن للمستخدم تعديل كل رقم يدوياً بلا حدود.
Targets calcTargets(Profile p) {
  final bmr = 10 * p.weight +
      6.25 * p.height -
      5 * p.age +
      (p.sex == 'm' ? 5 : -161);
  final factors = <String, double>{'low': 1.375, 'mid': 1.55, 'high': 1.725};
  final adjusts = <String, double>{'lose': -500, 'keep': 0, 'gain': 300};
  final perKg = <String, double>{'lose': 2.2, 'keep': 1.6, 'gain': 2.0};

  final factor = factors[p.activity] ?? 1.55;
  final adj = adjusts[p.goal] ?? 0;
  var kcal = ((bmr * factor + adj) / 10).round() * 10.0;
  if (kcal < 0) kcal = 0;
  final protein = (p.weight * (perKg[p.goal] ?? 1.6)).roundToDouble();
  final fat = (kcal * 0.25 / 9).roundToDouble();
  var carbs = ((kcal - protein * 4 - fat * 9) / 4).roundToDouble();
  if (carbs < 0) carbs = 0;
  return Targets(kcal: kcal, protein: protein, carbs: carbs, fat: fat);
}
