/// تطبيع عربي للبحث: إزالة التشكيل وتوحيد الهمزات والتاء المربوطة والألف المقصورة.
String normalizeAr(String s) {
  var t = s.replaceAll(RegExp('[\u064B-\u0652\u0640]'), '');
  t = t
      .replaceAll(RegExp('[أإآ]'), 'ا')
      .replaceAll('ة', 'ه')
      .replaceAll('ى', 'ي');
  return t.toLowerCase().trim();
}
