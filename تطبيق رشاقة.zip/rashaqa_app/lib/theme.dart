import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// ألوان التطبيق (مأخوذة من النموذج).
class C {
  static const bg = Color(0xFF0D1311);
  static const card = Color(0xFF16201C);
  static const border = Color(0xFF22302A);
  static const nav = Color(0xFF101814);
  static const ring = Color(0xFF1E2B26);
  static const text = Color(0xFFF2F7F4);
  static const muted = Color(0xFF8FA39A);
  static const green = Color(0xFF4ADE80);
  static const greenDark = Color(0xFF1B3326);
  static const greenBorder = Color(0xFF285238);
  static const protein = Color(0xFF7C9BFF);
  static const proteinBg = Color(0xFF1B2540);
  static const carbs = Color(0xFFFF9A4D);
  static const carbsBg = Color(0xFF3A2619);
  static const fat = Color(0xFFFFD23F);
  static const fatBg = Color(0xFF38311A);
  static const danger = Color(0xFFFF7A7A);
  static const dangerBg = Color(0xFF1C1213);
  static const dangerBorder = Color(0xFF5A2A2A);
}

ThemeData buildTheme() {
  final base = ThemeData(brightness: Brightness.dark, useMaterial3: true);
  final textTheme = GoogleFonts.tajawalTextTheme(base.textTheme)
      .apply(bodyColor: C.text, displayColor: C.text);
  return base.copyWith(
    scaffoldBackgroundColor: C.bg,
    colorScheme: const ColorScheme.dark(
      primary: C.green,
      secondary: C.green,
      surface: C.card,
    ),
    textTheme: textTheme,
    appBarTheme: AppBarTheme(
      backgroundColor: C.bg,
      elevation: 0,
      scrolledUnderElevation: 0,
      centerTitle: true,
      iconTheme: const IconThemeData(color: C.text),
      titleTextStyle: GoogleFonts.tajawal(
          fontSize: 19, fontWeight: FontWeight.w700, color: C.text),
    ),
    dividerColor: C.border,
    snackBarTheme: const SnackBarThemeData(
      backgroundColor: C.card,
      contentTextStyle: TextStyle(color: C.text),
      behavior: SnackBarBehavior.floating,
    ),
  );
}
