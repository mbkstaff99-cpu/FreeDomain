import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../theme.dart';

/// بطاقة بخلفية داكنة وحدود، مع تأثير لمس اختياري.
class AppCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final VoidCallback? onTap;
  final Color color;
  final Color borderColor;
  final double radius;

  const AppCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(14),
    this.onTap,
    this.color = C.card,
    this.borderColor = C.border,
    this.radius = 16,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: color,
      clipBehavior: Clip.antiAlias,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(radius),
        side: BorderSide(color: borderColor),
      ),
      child: InkWell(
        onTap: onTap,
        child: Padding(padding: padding, child: child),
      ),
    );
  }
}

/// مربع أيقونة ملوّن.
class IconBox extends StatelessWidget {
  final IconData icon;
  final Color fg;
  final Color bg;
  final double size;
  final double radius;

  const IconBox({
    super.key,
    required this.icon,
    required this.fg,
    required this.bg,
    this.size = 36,
    this.radius = 12,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration:
          BoxDecoration(color: bg, borderRadius: BorderRadius.circular(radius)),
      child: Icon(icon, color: fg, size: size * 0.55),
    );
  }
}

/// زر اختيار (شريحة) بارتفاع 44.
class ChoiceBtn extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;
  final double fontSize;
  final EdgeInsetsGeometry padding;

  const ChoiceBtn({
    super.key,
    required this.label,
    required this.selected,
    required this.onTap,
    this.fontSize = 14,
    this.padding = const EdgeInsets.symmetric(horizontal: 16),
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: selected ? C.green : C.card,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(22),
        side: const BorderSide(color: C.border),
      ),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Container(
          height: 44,
          padding: padding,
          alignment: Alignment.center,
          child: Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontSize: fontSize,
              fontWeight: selected ? FontWeight.w800 : FontWeight.w500,
              color: selected ? C.bg : C.text,
            ),
          ),
        ),
      ),
    );
  }
}

/// الزر الرئيسي الأخضر.
class PrimaryButton extends StatelessWidget {
  final String label;
  final VoidCallback? onPressed;
  final IconData? icon;

  const PrimaryButton({super.key, required this.label, this.onPressed, this.icon});

  @override
  Widget build(BuildContext context) {
    return FilledButton(
      onPressed: onPressed,
      style: FilledButton.styleFrom(
        backgroundColor: C.green,
        foregroundColor: C.bg,
        minimumSize: const Size.fromHeight(54),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        textStyle: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          if (icon != null) ...[Icon(icon, size: 20), const SizedBox(width: 8)],
          Text(label),
        ],
      ),
    );
  }
}

/// زر ثانوي بحدود خضراء.
class SoftGreenButton extends StatelessWidget {
  final String label;
  final VoidCallback onPressed;

  const SoftGreenButton({super.key, required this.label, required this.onPressed});

  @override
  Widget build(BuildContext context) {
    return TextButton(
      onPressed: onPressed,
      style: TextButton.styleFrom(
        backgroundColor: C.greenDark,
        foregroundColor: C.green,
        minimumSize: const Size.fromHeight(50),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
          side: const BorderSide(color: C.greenBorder),
        ),
        textStyle: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800),
      ),
      child: Text(label, textAlign: TextAlign.center),
    );
  }
}

/// حقل رقمي حر (بلا أي حدود على القيمة).
class NumBox extends StatelessWidget {
  final TextEditingController controller;
  final ValueChanged<String>? onChanged;
  final Color color;
  final double width;
  final double fontSize;
  final String semanticLabel;
  final Color borderColor;

  const NumBox({
    super.key,
    required this.controller,
    required this.semanticLabel,
    this.onChanged,
    this.color = C.text,
    this.width = 100,
    this.fontSize = 19,
    this.borderColor = C.border,
  });

  @override
  Widget build(BuildContext context) {
    final border = OutlineInputBorder(
      borderRadius: BorderRadius.circular(10),
      borderSide: BorderSide(color: borderColor),
    );
    return SizedBox(
      width: width,
      height: 44,
      child: Semantics(
        label: semanticLabel,
        textField: true,
        child: TextField(
          controller: controller,
          onChanged: onChanged,
          textAlign: TextAlign.center,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          style: TextStyle(
              color: color, fontSize: fontSize, fontWeight: FontWeight.w800),
          decoration: InputDecoration(
            isDense: true,
            filled: true,
            fillColor: C.bg,
            contentPadding: const EdgeInsets.symmetric(horizontal: 8),
            border: border,
            enabledBorder: border,
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: const BorderSide(color: C.green),
            ),
          ),
        ),
      ),
    );
  }
}

/// حقل نص عادي بنفس الشكل.
class TextBox extends StatelessWidget {
  final TextEditingController controller;
  final String hint;
  final ValueChanged<String>? onChanged;
  final ValueChanged<String>? onSubmitted;
  final IconData? prefix;
  final Widget? suffix;

  const TextBox({
    super.key,
    required this.controller,
    required this.hint,
    this.onChanged,
    this.onSubmitted,
    this.prefix,
    this.suffix,
  });

  @override
  Widget build(BuildContext context) {
    final border = OutlineInputBorder(
      borderRadius: BorderRadius.circular(14),
      borderSide: const BorderSide(color: C.border),
    );
    return TextField(
      controller: controller,
      onChanged: onChanged,
      onSubmitted: onSubmitted,
      style: const TextStyle(fontSize: 16, color: C.text),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: const TextStyle(color: C.muted),
        filled: true,
        fillColor: C.card,
        prefixIcon: prefix == null ? null : Icon(prefix, color: C.muted),
        suffixIcon: suffix,
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        border: border,
        enabledBorder: border,
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: C.green),
        ),
      ),
    );
  }
}

/// حلقة تقدم السعرات.
class RingPainter extends CustomPainter {
  final double progress;
  RingPainter(this.progress);

  @override
  void paint(Canvas canvas, Size size) {
    final center = size.center(Offset.zero);
    final radius = size.width / 2 - 8;
    final bg = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 12
      ..color = C.ring;
    canvas.drawCircle(center, radius, bg);
    final p = math.min(1.0, math.max(0.0, progress));
    final fg = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 12
      ..strokeCap = StrokeCap.round
      ..color = progress > 1.0 ? C.danger : C.green;
    canvas.drawArc(
      Rect.fromCircle(center: center, radius: radius),
      -math.pi / 2,
      2 * math.pi * p,
      false,
      fg,
    );
  }

  @override
  bool shouldRepaint(covariant RingPainter old) => old.progress != progress;
}

/// بطاقة ماكرو صغيرة (الصفحة الرئيسية).
class MacroTile extends StatelessWidget {
  final String label;
  final double value;
  final double target;
  final Color color;
  final Color bg;
  final IconData icon;

  const MacroTile({
    super.key,
    required this.label,
    required this.value,
    required this.target,
    required this.color,
    required this.bg,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    final ratio = target > 0 ? math.min(1.0, value / target) : 0.0;
    String f(double v) => (v == v.roundToDouble()) ? v.toStringAsFixed(0) : v.toStringAsFixed(1);
    return AppCard(
      padding: const EdgeInsets.all(12),
      child: Column(
        children: [
          IconBox(icon: icon, fg: color, bg: bg, size: 32, radius: 16),
          const SizedBox(height: 4),
          Text(label, style: const TextStyle(fontSize: 12, color: C.muted)),
          Text('${f(value)} غ',
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
          Text('من ${f(target)} غ',
              style: const TextStyle(fontSize: 11, color: C.muted)),
          const SizedBox(height: 6),
          ClipRRect(
            borderRadius: BorderRadius.circular(2),
            child: LinearProgressIndicator(
              value: ratio,
              minHeight: 4,
              backgroundColor: C.ring,
              valueColor: AlwaysStoppedAnimation<Color>(color),
            ),
          ),
        ],
      ),
    );
  }
}

/// صف قيمة غذائية (أيقونة + عنوان + قيمة) للقراءة فقط.
class InfoRow extends StatelessWidget {
  final String label;
  final String value;
  final Color? valueColor;
  const InfoRow({super.key, required this.label, required this.value, this.valueColor});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 14),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(fontSize: 15, color: C.muted)),
          Text(value,
              style: TextStyle(
                  fontSize: 17,
                  fontWeight: FontWeight.w800,
                  color: valueColor ?? C.text)),
        ],
      ),
    );
  }
}
