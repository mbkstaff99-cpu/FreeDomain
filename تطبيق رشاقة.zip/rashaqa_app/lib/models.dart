import 'package:shared_preferences/shared_preferences.dart';

/// طعام من المكتبة أو من أطعمة المستخدم. القيم لكل 100 غرام.
class Food {
  final int? id;
  final String name;
  final String category;
  final double kcal;
  final double protein;
  final double carbs;
  final double fat;
  final bool estimate;
  final bool custom;

  const Food({
    this.id,
    required this.name,
    required this.category,
    required this.kcal,
    required this.protein,
    required this.carbs,
    required this.fat,
    this.estimate = false,
    this.custom = false,
  });

  /// صف من assets/foods.json: [name, category, kcal, protein, carbs, fat, 'R'|'E']
  factory Food.fromList(List<dynamic> a) {
    return Food(
      name: a[0] as String,
      category: a[1] as String,
      kcal: (a[2] as num).toDouble(),
      protein: (a[3] as num).toDouble(),
      carbs: (a[4] as num).toDouble(),
      fat: (a[5] as num).toDouble(),
      estimate: a.length > 6 && a[6] == 'E',
    );
  }
}

/// سجل طعام تم تناوله في يوم معين.
class Entry {
  final int? id;
  final String date; // yyyy-MM-dd
  final String mealType; // breakfast | lunch | dinner | snack
  final String name;
  final double grams;
  final double kcal;
  final double protein;
  final double carbs;
  final double fat;

  const Entry({
    this.id,
    required this.date,
    required this.mealType,
    required this.name,
    required this.grams,
    required this.kcal,
    required this.protein,
    required this.carbs,
    required this.fat,
  });

  Map<String, Object?> toMap() => {
        'date': date,
        'meal_type': mealType,
        'name': name,
        'grams': grams,
        'kcal': kcal,
        'protein': protein,
        'carbs': carbs,
        'fat': fat,
        'created_at': DateTime.now().toIso8601String(),
      };

  factory Entry.fromMap(Map<String, Object?> m) {
    double d(Object? v) => (v as num?)?.toDouble() ?? 0;
    return Entry(
      id: m['id'] as int?,
      date: m['date'] as String,
      mealType: m['meal_type'] as String,
      name: m['name'] as String,
      grams: d(m['grams']),
      kcal: d(m['kcal']),
      protein: d(m['protein']),
      carbs: d(m['carbs']),
      fat: d(m['fat']),
    );
  }
}

class Totals {
  final double kcal;
  final double protein;
  final double carbs;
  final double fat;
  const Totals(this.kcal, this.protein, this.carbs, this.fat);
  static const Totals zero = Totals(0, 0, 0, 0);
  Totals operator +(Totals o) =>
      Totals(kcal + o.kcal, protein + o.protein, carbs + o.carbs, fat + o.fat);
}

class Targets {
  final double kcal;
  final double protein;
  final double carbs;
  final double fat;
  const Targets({
    required this.kcal,
    required this.protein,
    required this.carbs,
    required this.fat,
  });

  factory Targets.defaults() =>
      const Targets(kcal: 2500, protein: 150, carbs: 300, fat: 70);

  factory Targets.fromPrefs(SharedPreferences p) => Targets(
        kcal: p.getDouble('t_kcal') ?? 2500,
        protein: p.getDouble('t_protein') ?? 150,
        carbs: p.getDouble('t_carbs') ?? 300,
        fat: p.getDouble('t_fat') ?? 70,
      );

  Future<void> save(SharedPreferences p) async {
    await p.setDouble('t_kcal', kcal);
    await p.setDouble('t_protein', protein);
    await p.setDouble('t_carbs', carbs);
    await p.setDouble('t_fat', fat);
  }
}

class Profile {
  final String name;
  final double weight; // كغ
  final double height; // سم
  final int age;
  final String sex; // m | f
  final String activity; // low | mid | high
  final String goal; // lose | keep | gain

  const Profile({
    required this.name,
    required this.weight,
    required this.height,
    required this.age,
    required this.sex,
    required this.activity,
    required this.goal,
  });

  factory Profile.defaults() => const Profile(
        name: 'المستخدم',
        weight: 66,
        height: 187,
        age: 26,
        sex: 'm',
        activity: 'mid',
        goal: 'gain',
      );

  Profile copyWith({
    String? name,
    double? weight,
    double? height,
    int? age,
    String? sex,
    String? activity,
    String? goal,
  }) {
    return Profile(
      name: name ?? this.name,
      weight: weight ?? this.weight,
      height: height ?? this.height,
      age: age ?? this.age,
      sex: sex ?? this.sex,
      activity: activity ?? this.activity,
      goal: goal ?? this.goal,
    );
  }

  factory Profile.fromPrefs(SharedPreferences p) {
    final d = Profile.defaults();
    return Profile(
      name: p.getString('p_name') ?? d.name,
      weight: p.getDouble('p_weight') ?? d.weight,
      height: p.getDouble('p_height') ?? d.height,
      age: p.getInt('p_age') ?? d.age,
      sex: p.getString('p_sex') ?? d.sex,
      activity: p.getString('p_activity') ?? d.activity,
      goal: p.getString('p_goal') ?? d.goal,
    );
  }

  Future<void> save(SharedPreferences p) async {
    await p.setString('p_name', name);
    await p.setDouble('p_weight', weight);
    await p.setDouble('p_height', height);
    await p.setInt('p_age', age);
    await p.setString('p_sex', sex);
    await p.setString('p_activity', activity);
    await p.setString('p_goal', goal);
  }
}
